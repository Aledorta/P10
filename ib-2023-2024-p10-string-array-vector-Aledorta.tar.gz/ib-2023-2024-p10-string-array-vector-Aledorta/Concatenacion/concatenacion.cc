/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica
 *
 * @author Alejandro Dorta Luis
 * @date 23 Nov 2023
 * @brief Concatenar dos vectores
 * @see desarrollo de las funciones de concatenacion.h
 */

#include "concatenacion.h"

std::vector<double> Vector_concatenado(std::vector<double> vect1, std::vector<double> vect2) {
  std::vector<double> vector_concatendo;
  // Copia los elementos de vect1 al vector concatenado
  for (int i=0; i < vect1.size(); ++i) {
    vector_concatendo.push_back(vect1[i]);
  }
  // Copia los elementos de vect2 al vector concatenado
  for (int i=0; i < vect2.size(); ++i) {
    vector_concatendo.push_back(vect2[i]);
  }
  return vector_concatendo;
}