/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica
 *
 * @author Alejandro Dorta Luis
 * @date 23 Nov 2023
 * @brief Concatenar dos vectores
 * @see declaración de funciones
 */

#include <iostream>
#include <vector>

/**
 * @brief Concatena dos vectores de tipo double.
 *
 * Esta función toma dos vectores de tipo double como entrada y devuelve un nuevo vector
 * que es la concatenación de ambos.
 *
 * @param vect1 Primer vector a concatenar.
 * @param vect2 Segundo vector a concatenar.
 * @return Vector resultante de la concatenación de vect1 y vect2.
 */
std::vector<double> Vector_concatenado(std::vector<double> vect1, std::vector<double> vect2);