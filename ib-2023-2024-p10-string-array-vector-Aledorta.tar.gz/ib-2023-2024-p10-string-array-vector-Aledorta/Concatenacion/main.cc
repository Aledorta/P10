/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica
 *
 * @author Alejandro Dorta Luis
 * @date 23 Nov 2023
 * @brief Concatenar dos vectores
 * @see funcion principal
 */

#include <iostream>

#include "concatenacion.h"

int main(int argc, char *argv[]) {
  // Verifica si se proporciona la cantidad correcta de argumentos (2 en total, incluido el nombre del programa).
  if (argc < 2) {
    std::cout << argv[0] << ": Falta un número natural y dos reales como parámetro" << std::endl;
    std::cout << "Pruebe " << argv[0] << " --help para más información" << std::endl;
    exit(EXIT_SUCCESS);
  }
  std::string parameter{argv[1]};
  // Verifica si se proporciona el argumento "--help" para mostrar información de ayuda.
  if (parameter == "--help") {
    const std::string kHelpText = "Suma los números dentro de un vector, escribe como parámetro el número el tamaño del vector y los dos números en lo que están compreandidos";
    std::cout << kHelpText << std::endl;
    exit(EXIT_SUCCESS);
  }
  int size_vect1 = std::stoi(parameter), size_vect2;
  std::vector<double> vector1, vector2, vector_concatenado; 
  // Lee los primeros 'size_vect1' elementos desde la línea de comandos y los guarda en vector1.
  for (int i=0; i < size_vect1; ++i) {
    std::string parameter{argv[2+i]};
    vector1.push_back(std::stod(parameter));
  }
  std::string parameter2{argv[2+size_vect1]};
  size_vect2 = std::stod(parameter2);
  // Lee los siguientes 'size_vect2' elementos desde la línea de comandos y los guarda en vector2.
  for (int i = 0; i < size_vect2; ++i) {
    std::string parameter{argv[3+i+size_vect1]};
    vector2.push_back(std::stod(parameter));
  }
  // Concatena los dos vectores.
  vector_concatenado = Vector_concatenado(vector1, vector2);
  // Muestra los elementos del vector concatenado.
  for(int i = 0; i < vector_concatenado.size(); ++i) {
    std::cout << vector_concatenado[i] << " ";
  }
  std::cout << std::endl;
  return 0;
}