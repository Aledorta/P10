/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica
 *
 * @author Alejandro Dorta Luis
 * @date 23 Nov 2023
 * @brief De el máximo, promedio t mínimo de un vector aleatorio
 * @see desarrollo de funciones de max_prod_min.h
 */

#include "max_prod_min.h"

std::vector<double> GenerateVector(const int size, const double lower, const double upper) {
  std::vector<double> vector_aleatorio;
  // Semilla para el generador de números aleatorios
  std::random_device rd;
  std::mt19937 rng(rd());
  std::uniform_real_distribution<double> distribucion(lower, upper);
  for (int i=0; i < size; ++i) {
    vector_aleatorio.push_back(distribucion(rng));
    std::cout << vector_aleatorio[i] << " ";
  }
  std::cout << std::endl;
  return vector_aleatorio;
}

std::vector<double> Max_prod_min(std::vector<double> vector) {
  // Inicialización de variables para el cálculo de máximo, promedio y mínimo
  double max = vector[0], min = vector[0], promedio = vector[0];
  // Itera sobre los elementos del vector desde el segundo elemento (índice 1)
  for (int i=1; i < vector.size(); ++i) {
    if (max < vector[i]) {
      max = vector[i];
    }
    if (min > vector[i]) {
      min = vector[i];
    }
    promedio += vector[i];
  }
  // Calcula el promedio dividiendo la suma acumulada por el tamaño del vector
  promedio = promedio / vector.size();
  // Crea un vector resultante con los valores calculados
  std::vector<double> resultado;
  resultado.push_back(max);
  resultado.push_back(promedio);
  resultado.push_back(min);
  return resultado;
}