/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica
 *
 * @author Alejandro Dorta Luis
 * @date 23 Nov 2023
 * @brief Darle la vuelta a una cadena
 * @see funcion principal
 */

 #include <iostream>
 #include <vector>

void Reverse(std::vector<int> vector) {
  for (int i=vector.size() - 1; i >= 0; --i) {
    if (i == 0) {
      std::cout << vector[i];
    } else {
      std::cout << vector[i] << " ";
    }
  }
  std::cout << std::endl;
  return;
}

 int main() {
  int size, numero;
  while(std::cin >> size) {
    std::vector<int> vector;
    for (int i=0; i < size; ++i) {
      std::cin >> numero;
      vector.push_back(numero);
    }
    Reverse(vector);
  }
  return 0;
}

