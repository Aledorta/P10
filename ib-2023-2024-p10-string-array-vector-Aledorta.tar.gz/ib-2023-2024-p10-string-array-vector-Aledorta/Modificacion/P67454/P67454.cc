/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica
 *
 * @author Alejandro Dorta Luis
 * @date 23 Nov 2023
 * @brief Contar a,s
 * @see funcion principal
 */
#include <iostream>
#include <vector>

int Buscar_a(std::vector<char> cadena) {
  int n_a = 0;
  for (int i = 0; i < cadena.size(); ++i) {
    if (cadena[i] == 'a') {
      ++n_a;
    }
    if (cadena[i] == '.') {
      return n_a;
    }
  }
  return n_a;
}

int main() {
  char caracter;
  std::vector<char> cadena;
  while (std::cin >> caracter) {
    cadena.push_back(caracter);
  }
  std::cout << Buscar_a(cadena) << std::endl;
  return 0;
}





