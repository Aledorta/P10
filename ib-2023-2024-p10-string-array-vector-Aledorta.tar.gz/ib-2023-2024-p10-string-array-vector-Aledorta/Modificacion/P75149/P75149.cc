/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica
 *
 * @author Alejandro Dorta Luis
 * @date 23 Nov 2023
 * @brief Encontrar por lo menos una a
 * @see funcion principal
 */

#include <iostream>
#include <vector>

int Buscar_a(std::vector<char> cadena) {
  for (int i = 0; i < cadena.size(); ++i) {
    if (cadena[i] == 'a') {
      return 0;
    }
  }
  return 1;
}

int main() {
  char caracter;
  std::vector<char> cadena;
  while (std::cin >> caracter) {
    cadena.push_back(caracter);
    if (caracter == '.') {
      break;
    }
  }
  if (Buscar_a(cadena) == 0) {
    std::cout << "yes" << std::endl;
  } else {
    std::cout << "no" << std::endl;
  }
  return 0;
}
