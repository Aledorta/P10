/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica
 *
 * @author Alejandro Dorta Luis
 * @date 23 Nov 2023
 * @brief Genera un vector aleatorio
 * @see funcion principal
 */

#include <iostream>

#include "random.h"

int main() {
  std::vector<double> my_vector = GenerateVector(30, 5.0, 10.0);
  // Imprimir vector
  for (const auto& value: my_vector) {
    std::cout << "Component: " << value << std::endl;
  }
  return 0;
}