/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica
 *
 * @author Alejandro Dorta Luis
 * @date 23 Nov 2023
 * @brief Genera un vector aleatorio
 * @see funciones de random.h
 */

#include "random.h"

std::vector<double> GenerateVector(const int size, const double lower, const double upper) {
  std::vector<double> vector_aleatorio;
  // Semilla para el generador de números aleatorios
  std::random_device rd;
  std::mt19937 rng(rd());
  std::uniform_real_distribution<double> distribucion(lower, upper);
  for (int i=0; i < size; ++i) {
    vector_aleatorio.push_back(distribucion(rng));
  }
  return vector_aleatorio;
}