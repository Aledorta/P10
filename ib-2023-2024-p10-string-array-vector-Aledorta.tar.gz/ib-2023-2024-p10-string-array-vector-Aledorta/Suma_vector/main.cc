/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica
 *
 * @author Alejandro Dorta Luis
 * @date 23 Nov 2023
 * @brief Sumar dos vectores
 * @see funcion principal
 */

#include <iostream>

#include "suma_vector.h"

int main(int argc, char* argv[]) {
  // Verifica si se proporciona la cantidad correcta de argumentos (2 en total, incluido el nombre del programa).
  if (argc < 2) {
    std::cout << argv[0] << ": Falta un número natural y dos reales como parámetro" << std::endl;
    std::cout << "Pruebe " << argv[0] << " --help para más información" << std::endl;
    exit(EXIT_SUCCESS);
  }
  std::string parameter{argv[1]};
  // Verifica si se proporciona el argumento "--help" para mostrar información de ayuda.
  if (parameter == "--help") {
    const std::string kHelpText = "Suma los números dentro de un vector, escribe como parámetro el número el tamaño del vector y los dos números en lo que están compreandidos";
    std::cout << kHelpText << std::endl;
    exit(EXIT_SUCCESS);
  }
  float lower, upper;
  int size = std::stoi(parameter);
  std::string parameter2{argv[2]};
  lower = std::stoi(parameter2);
  std::string parameter3{argv[3]};
  upper = std::stoi(parameter3);
  std::vector<float> vector_suma = GenerateVector(size, lower, upper);
  // Imprime la suma
  std::cout << ReduceSum(vector_suma) << std::endl;
  return 0;
}