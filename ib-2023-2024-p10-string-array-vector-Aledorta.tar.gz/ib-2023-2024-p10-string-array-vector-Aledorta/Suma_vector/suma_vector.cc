/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica
 *
 * @author Alejandro Dorta Luis
 * @date 23 Nov 2023
 * @brief Sumar dos vectores
 * @see funciones de suma_vector.h
 */

#include "suma_vector.h"

std::vector<float> GenerateVector(int size, float lower, float upper) {
  std::vector<float> vector_aleatorio;
  // Semilla para el generador de números aleatorios
  std::random_device rd;
  std::mt19937 rng(rd());
  for (int i=0; i < size; ++i) {
    std::uniform_real_distribution<float> distribucion(lower, upper);
    vector_aleatorio.push_back(distribucion(rng));
  }
  return vector_aleatorio;  
}

float ReduceSum(std::vector<float> vector) {
  float suma = 0;
  // Recorre el vector
  for (int i=0; i < vector.size(); ++i) {
    suma += vector[i];
    std::cout << vector[i] << " ";
  }
  std::cout << std::endl;
  return suma;
}