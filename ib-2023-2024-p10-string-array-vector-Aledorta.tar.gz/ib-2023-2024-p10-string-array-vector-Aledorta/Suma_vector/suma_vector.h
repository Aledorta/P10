/**
 * Universidad de La Laguna
 * Escuela Superior de Ingeniería y Tecnología
 * Grado en Ingeniería Informática
 * Informática Básica
 *
 * @author Alejandro Dorta Luis
 * @date 23 Nov 2023
 * @brief Sumar dos vectores
 * @see declaración de funciones
 */

#include <iostream>
#include <vector>
#include <random>

/**
 * @brief Genera un vector de números aleatorios en el rango especificado.
 *
 * Esta función crea un vector de números aleatorios de tamaño especificado, 
 * donde cada elemento está en el rango [lower, upper].
 *
 * @param size Tamaño del vector a generar.
 * @param lower Valor mínimo permitido para los elementos del vector.
 * @param upper Valor máximo permitido para los elementos del vector.
 * @return Vector generado con números aleatorios en el rango [lower, upper].
 */
std::vector<float> GenerateVector(int size, float lower, float upper);
/**
 * @brief Calcula la suma de elementos en un vector de tipo float.
 *
 * Esta función toma un vector de números de tipo float y devuelve la suma de todos sus elementos.
 *
 * @param vector Vector de entrada para calcular la suma.
 * @return Suma de los elementos en el vector.
 */
float ReduceSum(std::vector<float> vector);