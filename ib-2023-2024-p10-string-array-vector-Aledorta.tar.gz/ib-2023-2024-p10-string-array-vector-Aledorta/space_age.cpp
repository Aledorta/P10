#include "space_age.h"

namespace space_age {

}  // namespace space_age
