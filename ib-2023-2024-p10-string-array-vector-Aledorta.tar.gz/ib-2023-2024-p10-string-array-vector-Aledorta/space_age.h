#if !defined(SPACE_AGE_H)
#define SPACE_AGE_H

namespace space_age {

}  // namespace space_age

#endif // SPACE_AGE_H